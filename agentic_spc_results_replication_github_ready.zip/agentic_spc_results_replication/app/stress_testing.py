from __future__ import annotations

import numpy as np
import pandas as pd

from .config import Config


SCENARIOS: dict[str, dict] = {
    "stable_null": {"slope": 0.0, "cap": 0.0, "intermittent": False, "context_error": 0.0, "missingness": 0.0},
    "small_gradual_a2_shift": {"slope": 0.25, "cap": 5.0, "intermittent": False, "context_error": 0.0, "missingness": 0.0},
    "gradual_a2_shift": {"slope": 0.55, "cap": 11.0, "intermittent": False, "context_error": 0.0, "missingness": 0.0},
    "large_gradual_a2_shift": {"slope": 0.85, "cap": 16.0, "intermittent": False, "context_error": 0.0, "missingness": 0.0},
    "intermittent_a2_shift": {"slope": 0.70, "cap": 10.0, "intermittent": True, "context_error": 0.0, "missingness": 0.0},
    "context_error": {"slope": 0.55, "cap": 11.0, "intermittent": False, "context_error": 0.30, "missingness": 0.0},
    "missingness_stress": {"slope": 0.55, "cap": 11.0, "intermittent": False, "context_error": 0.0, "missingness": 0.08},
}


def _ewma_signals(values: np.ndarray, phase1_hours: int, lam: float, L: float) -> np.ndarray:
    baseline = values[:phase1_hours]
    mu0 = float(np.mean(baseline))
    sigma0 = float(np.std(baseline, ddof=1))
    z_prev = mu0
    signals: list[int] = []
    for t, value in enumerate(values[phase1_hours:], start=1):
        z = lam * float(value) + (1.0 - lam) * z_prev
        sigma_z = sigma0 * np.sqrt(lam / (2.0 - lam) * (1.0 - (1.0 - lam) ** (2 * t)))
        signals.append(int(z > mu0 + L * sigma_z or z < mu0 - L * sigma_z))
        z_prev = z
    return np.asarray(signals, dtype=int)


def _single_replication(config: Config, scenario: str, seed: int, baseline_sigma: float) -> dict:
    spec = SCENARIOS[scenario]
    rng = np.random.default_rng(seed)
    phase2_hours = config.total_hours - config.phase1_hours
    fault_start_phase2 = config.degradation_start_hour - config.phase1_hours

    # The residual series is the post-risk-adjustment monitoring target.
    values = rng.normal(0.0, baseline_sigma, config.total_hours)
    missingness_rate = float(spec["missingness"])
    if missingness_rate > 0:
        eligible_per_hour = rng.binomial(config.specimens_per_hour, 1.0 - missingness_rate, config.total_hours)
        eligible_per_hour = np.maximum(eligible_per_hour, 1)
        values *= np.sqrt(config.specimens_per_hour / eligible_per_hour)
    else:
        eligible_per_hour = np.full(config.total_hours, config.specimens_per_hour)

    elapsed = np.maximum(0, np.arange(phase2_hours) - fault_start_phase2)
    effect = np.minimum(float(spec["cap"]), float(spec["slope"]) * elapsed)
    if bool(spec["intermittent"]):
        effect = np.where((elapsed % 12) < 7, effect, 0.0)
    values[config.phase1_hours:] += effect

    signals = _ewma_signals(values, config.phase1_hours, config.lambda_ewma, config.L_ewma)
    raw_signal_hours = int(signals.sum())
    pre_fault = signals[:fault_start_phase2]

    if scenario == "stable_null":
        return {
            "detected": np.nan,
            "delay_hours": np.nan,
            "raw_signal_hours": raw_signal_hours,
            "pre_fault_false_signal_rate": float(pre_fault.mean()) if len(pre_fault) else 0.0,
            "phase2_false_signal_rate": float(signals.mean()) if len(signals) else 0.0,
            "automatic_initial_action": np.nan,
            "credible_initial_case": np.nan,
            "quarantine_rate": float(1.0 - eligible_per_hour.mean() / config.specimens_per_hour),
        }

    post_fault = signals[fault_start_phase2:]
    detected = bool(post_fault.any())
    delay = int(np.argmax(post_fault)) if detected else np.nan

    # Scenario-level contextual reliability affects validation and governance,
    # never the existence of the raw chart signal itself.
    context_available = rng.random() >= float(spec["context_error"])
    credible_initial_case = bool(detected and context_available)
    automatic_initial_action = bool(credible_initial_case)

    return {
        "detected": float(detected),
        "delay_hours": delay,
        "raw_signal_hours": raw_signal_hours,
        "pre_fault_false_signal_rate": float(pre_fault.mean()) if len(pre_fault) else 0.0,
        "phase2_false_signal_rate": np.nan,
        "automatic_initial_action": float(automatic_initial_action),
        "credible_initial_case": float(credible_initial_case),
        "quarantine_rate": float(1.0 - eligible_per_hour.mean() / config.specimens_per_hour),
    }


def run_stress_tests(config: Config, baseline_sigma: float | None = None) -> pd.DataFrame:
    """Run a 500-replication synthetic stress test synchronized to the Phase I residual scale.

    The study estimates raw residual-EWMA behavior and the effect of contextual
    reliability on initial low-risk workflow authorization. It does not validate
    clinical effectiveness or a learned alarm-validation model.
    """
    baseline_sigma = float(config.stress_reference_sigma if baseline_sigma is None else baseline_sigma)
    if baseline_sigma <= 0:
        raise ValueError("baseline_sigma must be positive.")

    rows: list[dict] = []
    for scenario_number, scenario in enumerate(SCENARIOS):
        reps = [
            _single_replication(config, scenario, config.seed + scenario_number * 100_000 + rep, baseline_sigma)
            for rep in range(config.stress_repetitions)
        ]
        rep_df = pd.DataFrame(reps)
        is_null = scenario == "stable_null"
        rows.append(
            {
                "scenario": scenario,
                "replications": config.stress_repetitions,
                "detection_rate": float(rep_df["detected"].mean()) if not is_null else np.nan,
                "median_delay_hours": float(rep_df["delay_hours"].median()) if not is_null else np.nan,
                "mean_raw_signal_hours": float(rep_df["raw_signal_hours"].mean()),
                "pre_fault_false_signal_rate": float(rep_df["pre_fault_false_signal_rate"].mean()),
                "phase2_false_signal_rate": float(rep_df["phase2_false_signal_rate"].mean()) if is_null else np.nan,
                "credible_initial_case_rate": float(rep_df["credible_initial_case"].mean()) if not is_null else np.nan,
                "automatic_initial_action_rate": float(rep_df["automatic_initial_action"].mean()) if not is_null else np.nan,
                "mean_quarantine_rate": float(rep_df["quarantine_rate"].mean()),
            }
        )
    return pd.DataFrame(rows)
