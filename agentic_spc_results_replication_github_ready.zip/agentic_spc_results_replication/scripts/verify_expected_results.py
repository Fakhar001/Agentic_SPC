"""Verify that the deterministic reference scenario reproduced its key results."""
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

EXPECTED = {
    "Raw laboratory records ingested": "12980",
    "Eligible records used for SPC": "12866",
    "Quarantined records": "114",
    "Distinct data-integrity hours": "108",
    "Raw residual-EWMA signal hours": "235",
    "Pre-degradation raw signal hours": "0",
    "Initial SPC incident episodes": "1",
    "Persistent-signal escalation cases": "1",
    "First residual-EWMA detection": "2026-01-21 05:00:00",
    "Scenario-specific detection delay (hours)": "5.0",
    "Audit ledger records": "110",
    "Tamper-evident ledger hash chain valid": "True",
}


def normalise(value: object) -> str:
    text = str(value).strip()
    if text.endswith(".0") and text[:-2].isdigit():
        return text[:-2]
    return text


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=Path, default=Path("outputs/results_table.csv"))
    args = parser.parse_args()

    table = pd.read_csv(args.results)
    observed = {str(row["Metric"]): normalise(row["Result"]) for _, row in table.iterrows()}
    mismatches: list[str] = []
    for metric, expected in EXPECTED.items():
        actual = observed.get(metric)
        if actual != normalise(expected):
            mismatches.append(f"{metric}: expected={expected!r}, actual={actual!r}")
    if mismatches:
        raise SystemExit("Replication check failed:\n" + "\n".join(mismatches))
    print("Replication check passed: all key deterministic outputs match.")


if __name__ == "__main__":
    main()
