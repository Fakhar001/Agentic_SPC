from dataclasses import replace

from app.config import Config
from app.stress_testing import SCENARIOS, run_stress_tests


def test_stress_test_runs_all_governed_scenarios_with_small_replication_count():
    result = run_stress_tests(replace(Config(), stress_repetitions=3))
    assert set(result["scenario"]) == set(SCENARIOS)
    assert (result["replications"] == 3).all()
    assert "automatic_initial_action_rate" in result.columns
